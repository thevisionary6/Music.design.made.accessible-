---
name: mdma-backend
description: "Build the new MDMA backend library into the existing MDMA codebase — a SignalFlow-native Pattern/Scheduler/InputController layer that lives alongside the existing numpy-buffer DSP stack rather than replacing it. Use this skill whenever the user references MDMA, the new Pattern class, the Scheduler, PAR (Pattern at Audio Rate), PARScheduler, InputController, the SignalFlow integration, Session integration, the repo-prep work, or the triage/pare-down of old DSP modules. Use it even if the user just says 'work on the backend merge' or mentions specific transforms like .fast, .mod, .bf, .gate — those are all part of this skill's scope. Follow the specs in the references/ folder as the source of truth; do not improvise API shapes without consulting them. The skill also governs the merge process itself: which old modules port forward, which get renamed, which get rebuilt, and in what order."
---

# MDMA Backend (Merge + New Build)

A spec-driven skill for adding the new MDMA backend to the existing MDMA
codebase at https://github.com/thevisionary6/Music.design.made.accessible-.
The specs in `references/` are the source of truth for new components; the
roadmap below governs the merge with existing code.

## Project Context

MDMA is an accessibility-first audio production system. The author, Jake,
is a blind musician/developer working primarily via NVDA + Wispr Flow
voice dictation on Windows. This shapes several non-negotiables:

- **Explicit, non-idiomatic code is preferred over clever abstractions.**
  Code that mirrors the spec 1:1 is easier to verify by screen reader
  than code that uses metaprogramming, decorators stacked on decorators,
  or deep inheritance chains.
- **The API must be chain-friendly and dictation-friendly.** Short method
  names, consistent parameter ordering, no required keyword arguments
  where a positional would do.
- **No global keyboard grabs.** The KeyboardController in particular
  must not interfere with NVDA's focus handling.

## The Merge at a Glance

The existing MDMA codebase has a clean single-source-of-truth
architecture — Session owns state, DSP modules are independent, commands
are thin wrappers, interfaces are clients of the engine. This
architecture was (accidentally) a gift: adding the new SignalFlow-based
backend is an extension of Session rather than a rewrite of it.

**What the merge looks like in one paragraph:** A new
`mdma_rebuild/backend/` package is created containing Pattern, Clock,
Scheduler, PAR, PARScheduler, and InputController. Session grows new
SignalFlow-backed methods that route through this package. The existing
numpy-buffer DSP path continues to work unchanged. Individual DSP modules
get ported to SignalFlow-node form on demand, not all at once. The bridge
between the two worlds is offline render: the SignalFlow path produces
numpy buffers that populate `session.last_buffer`, so downstream code
(effects, render commands, AI analysis) still sees the same contract.

**What ports forward (keep, minimal changes):**

- `commands/` — all 30+ command modules are clean `cmd_xxx(session, args)
  -> str` wrappers. No rework needed.
- The command router currently living in `bmdma.py` — extract into
  `commands/router.py` during repo-prep.
- `ai/` — zero imports from the DSP production layer. Fully portable.
- `core/session.py` as the orchestrator — but pare it down first; at
  2566 LOC it's doing too much.
- `dsp/music_theory.py` — symbolic only, returns MIDI lists.
- `dsp/scaling.py` — the 1-100 accessibility scaling layer.
- `dsp/playback.py` — only 5 imports from the rest of the codebase, so
  the SignalFlow swap is surgical.
- Symbolic portions of `dsp/beat_gen.py` and `dsp/loop_gen.py` — drum
  primitives and note-list outputs.

**What gets renamed:**

- `dsp/pattern.py` → `dsp/buffer_rearranger.py`. It's a buffer-slicing
  engine, not a Pattern class. The name collision is nominal only. See
  `references/pattern_spec.md` for full context.

**What gets built fresh (the new specs):**

- `backend/pattern.py` — `Pattern` class per `references/pattern_spec.md`.
- `backend/clock.py` — `Clock` per `references/scheduler_spec.md`.
- `backend/scheduler.py` — `Scheduler`, `PARScheduler`, automation,
  render, per `references/scheduler_spec.md`.
- `backend/input_controller.py` — `InputController` and concrete
  controllers per `references/input_controller_spec.md`.

**What gets ported selectively as needed (not all at once):**

- `dsp/effects.py` (4400 LOC, 113 effects) — rewrite specific effects as
  SignalFlow-node DSP callables matching the new spec's
  `fn(input_node, **params) -> Node` signature. Port what gets used.
  Until ported, old effects remain accessible through the legacy Session
  methods.
- `dsp/monolith.py` (2100 LOC FM engine) — either port piece by piece,
  or rebuild as a SignalFlow graph keeping the old as reference.
- `dsp/convolution.py`, `dsp/granular.py` — same approach.

**What gets triaged and probably stripped** — see the Triage List below.

## Three Specs

The new components are defined across three reference documents. Read
them as a set before writing any code — cross-references between them
matter:

- `references/pattern_spec.md` — The `Pattern` class. Compositional
  transforms (`.fast`, `.slow`, `.t_p`, `.l`, `.gs`, `.ex`, `.cat`,
  `.pre`) and synthesis transforms (`.mod`, `.dist`, `.bf`, `.spec`,
  `.ir`, `.gate`, `.fx`). Includes test examples for every compositional
  transform.
- `references/scheduler_spec.md` — The `Scheduler` (event-rate) and
  `PARScheduler` (audio-rate, batched dispatch) classes, plus the
  `Clock` they share. Includes the parameter automation system and
  render functions. Includes integration points with Session.
- `references/input_controller_spec.md` — The agnostic
  `InputController` that translates keyboard, MIDI, OSC, and (future)
  gamepad input into a unified internal protocol consumable by the
  scheduler and automation layer. Includes NVDA-compatibility
  requirements and command-router integration.

Each spec has a "Merge Context" section at the top that explains how it
relates to existing code.

## Development Roadmap

Build in this order. Each phase should be completed and tested before
moving to the next. The ordering is dictated by dependencies: later
phases assume earlier ones work.

### Phase 0 — Repo prep (do this first)

Before adding any new code, prepare the existing codebase. This is
non-negotiable — the rest of the roadmap assumes these changes are
done.

**0.1 Extract the command router.**
Currently `bmdma.py` contains a `build_command_table()` function plus
the `COMMAND_OWNERS` dict. Extract these into a new module:
`mdma_rebuild/commands/router.py`. `bmdma.py` should import from there.
The router becomes independently testable and reusable from future
launchers (GUI, InputController handlers, test harnesses).

**0.2 Rename `dsp/pattern.py` to `dsp/buffer_rearranger.py`.**
Update imports throughout the codebase. The new name accurately
describes what the module does and frees the `Pattern` name for the new
class.

**0.3 Audit and pare `core/session.py`.**
At 2566 LOC, Session is doing too much. The new backend expects Session
to be the orchestrator, not a god object. Target: ≤ 1500 LOC, ideally
less. Specific cuts to consider:
- Move `play_last_buffer` / wav-writing utilities into a separate
  `core/audio_io.py`.
- Move the long tail of parameter accessors into a dedicated
  `core/session_params.py` or into dataclasses held by Session.
- Move `last_buffer` management and the buffer priority logic (the
  `_get_source_audio` kind of methods) into a `core/buffer_store.py`.
Do not rewrite behavior — just split.

**0.4 Audit the triage list.**
Run through the Triage List (below) and for each module: keep as-is,
keep with cleanup, or remove. Document the decision. Do not
silently delete anything the user hasn't approved — some modules may
have value that isn't obvious from the filename.

**Done when:** The router is in its own module, `dsp/pattern.py` no
longer exists (renamed), Session is under 1500 LOC, and every triage-
list module has an explicit keep/cut decision.

### Phase 1 — Pattern class (standalone)

Implement `Pattern` per `references/pattern_spec.md`, except:

- `_apply_chain`, `_apply_builtin_filter`, and `_apply_gate` can be
  stubs that raise `NotImplementedError` for the DSP-specific parts, as
  long as chain registration (appending to `self.chain`) works
  correctly.
- `.play()` should work for patterns with an empty chain, matching the
  existing `play.py` behavior.

New file: `mdma_rebuild/backend/pattern.py`.

**Done when:** All test examples in `pattern_spec.md` pass. Pattern is
usable standalone without touching Session.

### Phase 2 — Chain application

Fill in the DSP application stubs from phase 1:

- `_apply_chain` walks `self.chain` and wraps the voice node
  accordingly.
- `_apply_builtin_filter` maps `("bf", type, cutoff, res)` entries to
  SignalFlow filter nodes.
- `_apply_gate` applies a gate pattern as an amplitude envelope.
- DSP-callable transforms (`.mod`, `.dist`, `.spec`, `.ir`, `.fx`)
  invoke their registered callables with the spec signature
  `fn(input_node, **params) -> Node`.

**Done when:**
`Pattern([(60, 0.5)]).bf("lpf", 800).play(saw, graph)` produces
filtered audio, and custom DSP callables passed to `.mod()` work
end-to-end.

### Phase 3 — Clock and basic Scheduler (no automation, no PAR)

Implement `Clock` and `Scheduler` per `references/scheduler_spec.md`:

- Clock start/stop, `now()`, `set_tempo()`, `beats_to_seconds()`. When
  constructed by Session, bind to `session.bpm` (bidirectional sync).
- `Scheduler.add()`, `.loop()`, `.start()`, `.stop()`.
- `ScheduleHandle` with `.cancel()` and `.swap()`.
- `LoopHandle` with `.stop()` (graceful) and `.stop_immediately()`.
- Concurrent pattern dispatch across multiple handles.
- Dispatch mechanism for voices and chains without `graph.wait(dur)` —
  the clock replaces it.

New files: `mdma_rebuild/backend/clock.py`,
`mdma_rebuild/backend/scheduler.py`.

**Done when:** Two patterns play concurrently, a loop starts and stops
cleanly, `.swap()` replaces a pattern at the next event boundary, and
the Clock's tempo is in sync with `session.bpm`.

### Phase 4 — Automation

Add the automation layer to the scheduler:

- `AutomationSource` base class and concrete sources: `Constant`,
  `LFO`, `Ramp`, `Envelope`. Skip `ControllerSource` for now (phase 7).
- `Scheduler.bind_chain_param()`, `.bind_tempo()`,
  `.bind_master_volume()`. Skip `.bind_mod_speed()` until PAR exists.
- `BindingHandle.unbind()`.
- Automation dispatch on each scheduler tick.

**Done when:** An `LFO` bound to a filter cutoff audibly sweeps the
filter during pattern playback.

### Phase 5 — Render + Session integration

Two deliverables in this phase:

**5a. Render functions.** `render_pattern(...)` and
`render_schedule(...)` per the spec. Keep audio-production separable
from wav-writing for the future `render_to_buffer` path.

**5b. Session integration.** Add the new SignalFlow-backed methods to
Session:
- `session.play_pattern(pattern, shape)` — plays via
  `Pattern.play()`, single-shot.
- `session.schedule(pattern, shape, ...)` — delegates to Scheduler.
- `session.loop(pattern, shape, ...)` — delegates to Scheduler.
- `session.render_pattern(pattern, shape, path)` — offline render;
  also populates `session.last_buffer` so downstream code sees the
  rendered audio.

These methods coexist with existing buffer-based methods like
`session.generate_tone`. New commands can use the new methods; old
commands keep working.

**Done when:** A new `/playp` or similar command can play a Pattern via
Session, and `session.last_buffer` is populated correctly after a
`session.render_pattern` call so existing effects commands work on the
rendered output.

### Phase 6 — PAR and PARScheduler

Implement audio-rate patterns and their dedicated scheduler:

- `PAR(Pattern)` subclass with `mod_speed`.
- `PARScheduler` with batched dispatch.
- `PARScheduleHandle.set_mod_speed()` for live mutation.
- `Scheduler.bind_mod_speed()` automation binding from phase 4.

The performance-sensitive path. Profile and optimize per the spec's
implementation notes. Get correctness first.

**Done when:** A PAR pattern runs at high `mod_speed` without choking,
`mod_speed` can be mutated live, and an automation source can drive it.

### Phase 7 — InputController

Implement the full `input_controller_spec.md`:

- `InputEvent`, `InputChannel`, `Controller` interfaces.
- `InputController` aggregator with namespace aliases, `.on()`
  handlers, glob matching, thread-safe poll loop.
- Concrete controllers: `KeyboardController`, `MidiController`,
  `OSCController`. `GamepadController` is deferred but the interface
  should not foreclose it.
- `ControllerSource` automation source that reads from an
  `InputChannel`.
- Handler path from InputController → `commands/router.py` → Session,
  for "MIDI pad triggers slash command" use cases.

**KeyboardController must not install a global hook** — use focus-scoped
input only, to preserve NVDA compatibility.

**Done when:** A MIDI CC drives a chain parameter via automation, a
MIDI pad press fires a slash command through the router, a keyboard
press triggers a scheduler `.loop()` call via a handler, and the
InputController runs without blocking the scheduler.

### Phase 8+ — Selective DSP porting (ongoing)

After the backend is functional, begin porting specific old DSP modules
to SignalFlow-node form as real use cases demand. Suggested starting
targets:

- The most-used effects from `dsp/effects.py` (reverb, delay,
  distortion, filter variants).
- Core FM synthesis from `dsp/monolith.py`, rebuilt as a parametric
  SignalFlow graph.
- Convolution reverb from `dsp/convolution.py`.

Each port should match the new DSP callable signature
`fn(input_node, **params) -> Node` so it drops into `.mod()`,
`.dist()`, `.fx()`, etc.

Do not attempt to port everything. The old numpy-buffer path remains
valid for effects that haven't been ported.

## Triage List (for Phase 0)

These old-codebase modules need an explicit keep/cut decision during
repo-prep. Do not silently delete — surface each one to the user.

**Likely keep (useful in their current form):**

- `dsp/streaming.py` — SoundCloud/YouTube audio ingestion. Useful
  independent of the audio production paradigm.
- `dsp/advanced_ops.py` — contains a `UserStack` for user variables
  accessible across commands. Accessibility-relevant and likely
  keepable.
- `dsp/scaling.py` — the 1-100 parameter abstraction used throughout.
  Keep.
- `dsp/music_theory.py` — symbolic. Keep.
- `dsp/envelopes.py` — small and useful. Keep.
- `dsp/transforms.py` — audit, but likely keep.
- `dsp/generators.py` — audit, some probably keepable.

**Likely keep but may need bug pass:**

- `dsp/dj_mode.py` — 3367 LOC. The deck control logic is valuable.
  Audio mixing needs to route through Scheduler eventually (noted as
  open question in scheduler spec). Pare bugs; defer audio rework.
- `dsp/beat_gen.py` and `dsp/loop_gen.py` — mixed symbolic and
  buffer-producing code. Keep symbolic parts, rebuild buffer
  generators as SignalFlow graphs over time.

**Likely pare significantly:**

- `dsp/performance.py` (852 LOC), `dsp/enhancement.py` (810 LOC),
  `dsp/stems.py` (796 LOC), `dsp/visualization.py` (330 LOC) — each
  needs individual audit. Many "advanced feature" modules in the
  original codebase were built speculatively and may not have users.
- `commands/stub_cmds.py` (1580 LOC of stubs) — stubs are
  low-hanging fruit for removal if they're not in use.

**Audit before touching:**

- `commands/advanced_cmds.py` (3025 LOC), `commands/fx_cmds.py` (3312
  LOC), `commands/dj_cmds.py` (3347 LOC), `commands/dsl_cmds.py`
  (2496 LOC), `commands/synth_cmds.py` (2659 LOC) — these are the
  largest command modules. Check for duplicate functionality and
  dead code before paring.

The goal of the triage is not aggressive deletion. The goal is to know
what exists and why before adding SignalFlow-based code on top of it.

## Conventions and Non-Negotiables

### API shape

- **Every compositional and synthesis transform returns a new
  `Pattern`.** No in-place mutation. Use
  `Pattern._from_parts(events, chain)` internally.
- **DSP callable signature is fixed:**
  `fn(input_node, **params) -> Node`. Do not deviate.
- **Durations are floats, in seconds, with full floating-point
  precision.** No integer snapping anywhere unless the spec calls for
  it.
- **Method names are short and dictation-friendly.** `.fast`, `.slow`,
  `.t_p`, `.l`, `.gs`, `.ex`, `.cat`, `.pre`, `.mod`, `.dist`, `.bf`,
  `.spec`, `.ir`, `.gate`, `.fx`. Do not rename these.

### Code style

- **Explicit over clever.** A loop that does the thing is better than
  a comprehension hiding a side effect. A class with named methods is
  better than a function returning a function.
- **Type hints on public methods.** Helps screen readers and helps
  future maintenance.
- **Docstrings quote the spec.** Each public method's docstring should
  paraphrase the behavior and list the test examples from the spec,
  so a reader doesn't have to flip files.
- **No magic.** No metaclasses, no `__getattr__` tricks, no decorators
  that rewrite method bodies.

### Threading

- The scheduler and PARScheduler each run their own loop thread.
- The InputController runs its own poll thread.
- Scheduler mutation methods (`.add`, `.swap`, `.bind_*`) must be
  thread-safe.
- Session methods called from InputController handlers must be
  thread-safe. The existing Session is not fully thread-safe; audit
  and add a coarse-grained lock as part of phase 5 or phase 7.

### Testing

- Every spec that has test examples gets unit tests using those
  examples as fixtures.
- Tests should not require audio hardware where possible. For
  synthesis transforms, mock the SignalFlow node interface or test at
  the chain-registration level (assert `pattern.chain == expected`)
  rather than asserting audio output.
- Integration tests with real audio go in a separate `tests/audio/`
  directory that can be skipped on CI.

## Out of Scope for v1

The specs call these out explicitly. Do not implement them unless the
user asks:

- Polyphony within a single pattern (overlapping voices).
- Generalizing Pattern to Sound/Over primitive dicts beyond
  `(note, dur)`.
- Mid-event pattern swap.
- Transform-argument automation (`.fast(live_source)`).
- `render_to_buffer` (future GUI support — preserve the architecture
  but don't build the function).
- Output controllers (LED feedback, OSC-out).
- MIDI clock sync.
- Quantization at schedule time.
- Gamepad controller implementation (keep the interface open).
- Learn mode for automation.
- Wholesale port of all 113 effects from `dsp/effects.py` — port what
  gets used.
- Wholesale rewrite of `dsp/monolith.py` — port piece by piece.
- DJ mode rework to route through Scheduler — deferred.

If a user request falls into this list, flag it and confirm before
going beyond the spec.

## When the Specs Disagree or a Case Isn't Covered

The specs were written as a set and are mostly consistent, but edge
cases will come up. The order of precedence:

1. If a test example in a spec is unambiguous, follow the test
   example.
2. If the spec body describes the behavior, follow the body.
3. If neither covers the case, stop and ask the user rather than
   guessing. The user has strong opinions about API shape and would
   rather clarify than refactor later.

Do not invent new public methods, new chain entry shapes, or new
`AutomationSource` types without asking. Internal helpers are fine.

## When the Merge Surfaces Ambiguity

The merge will surface cases where the old codebase and the new spec
could each plausibly claim ownership of a behavior. General guidance:

- **Audio production inside Scheduler-driven flow:** the new SignalFlow
  path wins.
- **Audio production inside existing command flow (`/tone`, `/fx`,
  etc.):** the old numpy-buffer path wins until those commands are
  explicitly ported.
- **Tempo:** one source of truth, `session.bpm` ↔ `clock.tempo`, kept
  in sync.
- **Buffer vs. graph at module boundaries:** if in doubt, render the
  graph to a buffer at the boundary and populate
  `session.last_buffer`. The buffer contract is older and more deeply
  assumed; the graph path should accommodate it rather than force
  rewrites.

When in doubt, preserve existing behavior. The goal is additive, not
disruptive.
