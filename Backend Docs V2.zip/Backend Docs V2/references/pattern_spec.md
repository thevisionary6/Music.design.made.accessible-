# Pattern Class Spec — MDMA Backend V2

## Merge Context

This spec defines the `Pattern` class for the MDMA backend — a new
component being added to an existing MDMA codebase. The merge path is
additive: this Pattern lives in a new `mdma_rebuild/backend/` package and
does not replace any existing module wholesale.

Two relevant notes for anyone reading this in the merge context:

1. **There is an existing `mdma_rebuild/dsp/pattern.py` in the old
   codebase.** It is misnamed — it is a buffer-rearrangement engine, not a
   Pattern class. As part of the repo-prep phase, it will be renamed to
   `dsp/buffer_rearranger.py`. There is no conceptual conflict between the
   old module and this new `Pattern` class; the collision is purely
   nominal.

2. **The new `Pattern` is SignalFlow-native.** The rest of the old MDMA
   DSP layer operates on numpy buffers. Session will grow SignalFlow-backed
   methods that coexist with the old numpy-buffer methods, and the
   SignalFlow path can produce a numpy buffer at the end via offline
   render when downstream code (effects, render, AI analysis) expects one.
   This lets migration be gradient, not big-bang.

The rest of this spec defines the Pattern class itself, unchanged by the
merge context.

---

## Purpose

`Pattern` is the core class of the MDMA backend library. It represents a
sequence of `(note, duration)` events and provides a fluent, chainable API for
both **compositional transforms** (reshaping the event list) and **synthesis
transforms** (building up a DSP chain to be applied at playback).

All transforms return a **new `Pattern` instance**; the original is never
mutated. This allows chaining like:

```python
melody.fast(2).t_p(7).mod(fm).dist(soft_clip).play(saw, graph)
```

## Core Data Model

A `Pattern` holds:

1. **`events`** — a list of `(note: float, duration: float)` tuples.
   - `note` is a MIDI note number. Float-valued, so microtonal transposition
     works cleanly.
   - `duration` is in seconds. Float.
2. **`chain`** — an ordered list of DSP transform specs, each a tuple of
   `(kind, callable_or_params)`. Empty by default. Applied at `.play()` time,
   outer call = later in chain. `.mod(fm).dist(clip)` produces a chain that
   applies `fm` first, then `clip`.

Empty patterns are legal: `Pattern([])` has `events == []` and is a no-op on
`.play()`. It acts as the identity for `.cat()` and `.pre()`.

## Constructor

```python
Pattern(patt: list[tuple[float, float]])
```

- `patt`: list of `(note, duration)` tuples. Both values are coerced to `float`.
- `chain` is always initialized empty. Transforms that add to the chain
  (`.mod`, `.dist`, `.bf`, `.spec`, `.ir`, `.gate`, `.fx`) return a new Pattern
  with a copied-and-extended chain.

### Internal constructor (for transforms)

Transforms need to produce new Patterns with both events and chain state. Use a
private classmethod:

```python
@classmethod
def _from_parts(cls, events: list[tuple[float, float]], chain: list) -> "Pattern":
    p = cls.__new__(cls)
    p.events = list(events)
    p.chain = list(chain)
    return p
```

This avoids re-running constructor coercion on internal data and keeps the
public constructor simple.

---

## Compositional Transforms

These operate on the event list. All return a new `Pattern` with the same
`chain` as the original.

### `.fast(n: float) -> Pattern`

Scales all durations by `1/n`. `n=2` → twice as fast (durations halved).
`n=0.5` → half as fast (durations doubled).

**Behavior:** `new_durs = [d / n for d in durs]`. Notes unchanged. `n` must be
positive; `n <= 0` raises `ValueError`.

**Test examples:**
```python
Pattern([(60, 0.5), (62, 0.5)]).fast(2).events == [(60.0, 0.25), (62.0, 0.25)]
Pattern([(60, 0.5)]).fast(0.5).events == [(60.0, 1.0)]
Pattern([]).fast(2).events == []
```

### `.slow(n: float) -> Pattern`

Scales all durations by `n`. Inverse of `.fast()`. Provided as a convenience
since it reads more naturally in some contexts.

**Behavior:** `new_durs = [d * n for d in durs]`. Notes unchanged. `n` must be
positive.

**Test examples:**
```python
Pattern([(60, 0.25), (62, 0.25)]).slow(2).events == [(60.0, 0.5), (62.0, 0.5)]
Pattern([(60, 0.5)]).slow(0.5).events == [(60.0, 0.25)]
```

### `.t_p(n: float) -> Pattern`

Transposes every note by `n` semitones. Float-valued, so microtonal shifts are
supported.

**Behavior:** `new_notes = [note + n for note, _ in events]`. Durations
unchanged.

**Test examples:**
```python
Pattern([(60, 0.25), (64, 0.25)]).t_p(7).events == [(67.0, 0.25), (71.0, 0.25)]
Pattern([(60, 0.25)]).t_p(-12).events == [(48.0, 0.25)]
Pattern([(60, 0.25)]).t_p(0.5).events == [(60.5, 0.25)]  # quarter-tone up
```

### `.l(target_duration: float) -> Pattern`

Proportionally rescales all durations so the total pattern length equals
`target_duration`. Uses floating-point precision — no grid snapping.

**Behavior:** Let `total = sum(durs)`. If `total == 0`, returns a copy
unchanged. Otherwise `scale = target_duration / total` and
`new_durs = [d * scale for d in durs]`.

`target_duration` must be positive; non-positive raises `ValueError`.

**Test examples:**
```python
Pattern([(60, 0.25), (62, 0.25), (64, 0.5)]).l(2.0).events == \
    [(60.0, 0.5), (62.0, 0.5), (64.0, 1.0)]
Pattern([(60, 1.0), (62, 1.0)]).l(1.0).events == [(60.0, 0.5), (62.0, 0.5)]
Pattern([]).l(2.0).events == []
```

### `.gs(a: float, b: float) -> Pattern`

Groove-swing. Alternates duration multipliers: first event scaled by `a`,
second by `b`, third by `a`, fourth by `b`, and so on.

**Behavior:** For event index `i`, multiplier is `a` if `i % 2 == 0` else `b`.
Notes unchanged.

**Test examples:**
```python
Pattern([(60, 0.25), (62, 0.25), (64, 0.25), (65, 0.25)]).gs(1.5, 0.5).events == \
    [(60.0, 0.375), (62.0, 0.125), (64.0, 0.375), (65.0, 0.125)]
Pattern([(60, 1.0)]).gs(2.0, 0.5).events == [(60.0, 2.0)]  # single event gets `a`
```

### `.ex(note: float, dur: float) -> Pattern`

Extends the pattern by appending one `(note, dur)` event.

**Behavior:** `new_events = events + [(float(note), float(dur))]`.

**Test examples:**
```python
Pattern([(60, 0.25)]).ex(62, 0.5).events == [(60.0, 0.25), (62.0, 0.5)]
Pattern([]).ex(60, 1.0).events == [(60.0, 1.0)]
```

### `.cat(other: Pattern) -> Pattern`

Concatenates `other` at the end of this pattern.

**Behavior:** `new_events = self.events + other.events`. The resulting
Pattern's `chain` is `self.chain` — `other`'s chain is discarded. (Rationale:
the chain is a playback property of the left-hand pattern; mixing two chains
ambiguously is worse than an explicit rule.)

**Test examples:**
```python
a = Pattern([(60, 0.25)])
b = Pattern([(62, 0.5)])
a.cat(b).events == [(60.0, 0.25), (62.0, 0.5)]
a.cat(Pattern([])).events == [(60.0, 0.25)]
Pattern([]).cat(a).events == [(60.0, 0.25)]
```

### `.pre(other: Pattern) -> Pattern`

Prepends `other` at the beginning of this pattern. Inverse of `.cat()`.

**Behavior:** `new_events = other.events + self.events`. Chain handling same
as `.cat()` — result uses `self.chain`.

**Test examples:**
```python
a = Pattern([(60, 0.25)])
b = Pattern([(62, 0.5)])
a.pre(b).events == [(62.0, 0.5), (60.0, 0.25)]
```

### Note on algorithms inherited from the old `pattern.py`

The old `dsp/pattern.py` (being renamed to `dsp/buffer_rearranger.py`) has ten
algorithms that operate on rendered audio buffers: staccato, legato, stutter,
bounce, reverse, random, humanize, glide, general, and audiorate. Several of
these (reverse, bounce, stutter, humanize, random) are conceptually
compositional transforms — they reorder or alter events rather than requiring
buffer slicing.

These are **not in scope for v1 of this spec**, but they are natural
additions for a later pass. If added, they should live alongside the
existing compositional transforms and follow the same return-a-new-Pattern
discipline.

---

## Synthesis Transforms

These **do not modify events**. They append a spec to the Pattern's `chain`.
The chain is consumed at `.play()` time and wraps the voice node produced by
`shape(note)`.

### DSP function signatures

Every DSP callable passed to a synthesis transform must match this convention:

```python
def my_dsp(input_node: Node, **params) -> Node:
    """Takes the current voice node, returns a new node wrapping or
    replacing it."""
    ...
```

- **First positional argument is always `input_node`** — the node to wrap or
  process. This is what the transform feeds in at playback time.
- **Return value is the new output node** — what the next link in the chain
  (or the graph output) will see.
- Any additional parameters are passed through via `**params` from the
  transform call site.

Example:
```python
def fm_mod(input_node, carrier_freq=440, mod_index=2.0):
    modulator = SineOscillator(carrier_freq * mod_index) * carrier_freq
    return SineOscillator(carrier_freq + modulator) * input_node
```

### `.mod(dsp_fn: Callable, **params) -> Pattern`

Adds a modulation stage (FM, AM, RM, or any arbitrary modulation function).

**Chain entry:** `("mod", dsp_fn, params)`

**Test examples:**
```python
p = Pattern([(60, 0.25)]).mod(fm_mod, mod_index=3.0)
p.chain == [("mod", fm_mod, {"mod_index": 3.0})]
p.events == [(60.0, 0.25)]  # events untouched
```

### `.dist(dsp_fn: Callable, **params) -> Pattern`

Adds a distortion / waveshaping / clipping stage. Semantically identical to
`.mod()` — the separate name is for readability in chains and for future
differentiation (e.g., default oversampling for distortion).

**Chain entry:** `("dist", dsp_fn, params)`

### `.bf(filter_type: str, cutoff: float, resonance: float = 0.0) -> Pattern`

Basic built-in filter. Implemented inline in the Pattern class (no external
callable) since the scope is fixed.

**Allowed `filter_type` values:**
- `"lpf"` — low-pass
- `"hpf"` — high-pass
- `"bpf"` — band-pass
- `"notch"` — notch / band-reject

(Allpass is excluded — it's a delay primitive, not a transformer filter.
Low-shelf and high-shelf are excluded — they're EQ shaping, not standard
transformer filters.)

**Chain entry:** `("bf", filter_type, cutoff, resonance)`

**Test examples:**
```python
Pattern([(60, 0.25)]).bf("lpf", 1000).chain == [("bf", "lpf", 1000.0, 0.0)]
Pattern([(60, 0.25)]).bf("bpf", 800, 0.7).chain == [("bf", "bpf", 800.0, 0.7)]
Pattern([(60, 0.25)]).bf("badtype", 1000)  # raises ValueError
```

### `.spec(dsp_fn: Callable, **params) -> Pattern`

Adds a spectral / FFT-based stage (excluding convolution, which has its own
transform).

**Chain entry:** `("spec", dsp_fn, params)`

### `.ir(dsp_fn: Callable, **params) -> Pattern`

Adds a convolution / impulse-response / granular stage. Covers convolution
reverbs, IR-based effects, and granular synthesis.

**Chain entry:** `("ir", dsp_fn, params)`

### `.gate(rhythm_pattern: Pattern) -> Pattern`

Applies a rhythmic gate to the output. Implemented inline (compositional in
spirit, even though it affects audio).

**`rhythm_pattern`**: a `Pattern` whose events are `(gate_state, segment_duration)`
where `gate_state` is `1` (open) or `0` (closed). The rhythm pattern loops for
the full duration of the host pattern's playback.

**Chain entry:** `("gate", rhythm_pattern)`

**Test examples:**
```python
# Quarter-note on/off gate
g = Pattern([(1, 0.25), (0, 0.25)])
p = Pattern([(60, 2.0)]).gate(g)
p.chain == [("gate", g)]
```

### `.fx(dsp_fn: Callable, **params) -> Pattern`

Catch-all for custom DSP: delay-based effects, custom filters, anything not
covered by the other categories. Same shape as `.mod` / `.dist` / `.spec` / `.ir`.

**Chain entry:** `("fx", dsp_fn, params)`

### Note on porting old effects to the new chain

The old codebase has `mdma_rebuild/dsp/effects.py` (~4400 LOC, 113+ effects)
and `mdma_rebuild/dsp/monolith.py` (~2100 LOC, FM synth engine). These are
numpy-buffer-based. They are **not being ported wholesale** in the merge.

Individual effects get rewritten as SignalFlow-node DSP callables matching
the signature above, as needed by real use cases. Until ported, the old
numpy-buffer effects remain available via the legacy command pathway
through Session. There is no requirement to port all 113 effects; port what
gets used.

---

## Playback

### `.play(shape: Callable, graph: AudioGraph) -> None`

Plays the pattern through the audio graph.

**`shape`** signature:
```python
def shape(note: float) -> Node:
    """Given a MIDI note number, return a voice node ready to be played."""
    ...
```

**Playback procedure:**

1. If `events` is empty, return immediately.
2. For each `(note, dur)` in `events`:
   a. Build the voice: `voice = shape(note)`
   b. Apply the chain in order: for each entry in `self.chain`, wrap the
      current node by invoking the corresponding DSP. Chain application is
      left-to-right (index 0 is innermost/first applied; last entry is
      outermost/last applied).
   c. Call `.play()` on the final output node.
   d. `graph.wait(dur)`.
   e. Call `.stop()` on the output node.

**Chain application pseudocode:**

```python
def _apply_chain(self, voice: Node) -> Node:
    current = voice
    for entry in self.chain:
        kind = entry[0]
        if kind in ("mod", "dist", "spec", "ir", "fx"):
            _, fn, params = entry
            current = fn(current, **params)
        elif kind == "bf":
            _, ftype, cutoff, res = entry
            current = _apply_builtin_filter(current, ftype, cutoff, res)
        elif kind == "gate":
            _, rhythm = entry
            current = _apply_gate(current, rhythm)
    return current
```

`_apply_builtin_filter` and `_apply_gate` are internal helpers to be
implemented using SignalFlow's filter and envelope primitives.

### Note: `.play()` vs Scheduler

`Pattern.play()` is the simple standalone path — sequential, blocking via
`graph.wait(dur)`. It is sufficient for single-pattern playback and is the
path Session's new SignalFlow-backed `play_pattern(...)` method wraps.

For concurrency, looping, live mutation, automation, or input-driven
playback, use the `Scheduler` (see scheduler_spec_v2.md). The Scheduler
does **not** replace `.play()`; it is purely additive.

---

## Immutability and Chaining

Every transform method returns a new `Pattern`. Self is never mutated. The
implementation pattern for every transform is:

```python
def some_transform(self, ...):
    new_events = ...  # or list(self.events) if unchanged
    new_chain = list(self.chain)  # or self.chain + [new_entry]
    return Pattern._from_parts(new_events, new_chain)
```

This makes long chains safe and predictable:

```python
base = Pattern([(60, 0.25), (64, 0.25), (67, 0.25)])
variation_a = base.fast(2).t_p(5)
variation_b = base.slow(2).mod(fm_mod)
# base is untouched; variation_a and variation_b are independent.
```

---

## Error Handling Summary

| Condition                              | Behavior                 |
|----------------------------------------|--------------------------|
| `.fast(n)` with `n <= 0`               | `ValueError`             |
| `.slow(n)` with `n <= 0`               | `ValueError`             |
| `.l(target)` with `target <= 0`        | `ValueError`             |
| `.l(target)` with empty pattern        | Returns empty Pattern    |
| `.l(target)` with total duration == 0  | Returns copy unchanged   |
| `.bf(type, ...)` with unknown type     | `ValueError`             |
| `.play()` on empty pattern             | Returns immediately      |
| `.cat` / `.pre` with empty other       | Identity (returns self's events) |

---

## Open Questions / Future Work

These are deliberately not in scope for the first pass, but worth flagging:

1. **Polyphony and overlap.** Current `.play()` is strictly sequential
   (`wait` + `stop`). Overlapping events require a scheduler layer. Out of
   scope for v1.
2. **Pattern over arbitrary primitives.** Extending from `(note, duration)`
   to full Sound/Over primitive dicts (freq, amp, partial, pulse, etc.) is
   a future generalization. Keep the current `(note, dur)` shape for now.
3. **Chain merging on `.cat` / `.pre`.** Currently takes the left-hand
   chain. Could be revisited if a use case emerges.
4. **Default shape bound to Pattern.** Currently `shape` is passed at play
   time. Could add `.with_shape(fn)` later if it becomes ergonomic to
   bind it once.
5. **Rehoming old rearranger algorithms.** Reverse, bounce, stutter,
   humanize, random — all conceptually compositional. Natural additions
   when the old `buffer_rearranger.py` is deprecated or its algorithms
   want an event-level equivalent.
