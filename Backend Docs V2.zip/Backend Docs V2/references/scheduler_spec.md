# Scheduler Spec — MDMA Backend V2

## Merge Context

This spec defines the `Scheduler` and `PARScheduler` for the MDMA backend
— new components being added to the existing MDMA codebase. Relevant notes
for the merge:

1. **The Scheduler lives in the new `mdma_rebuild/backend/` package.** It
   does not replace any existing module. The old audio flow through
   `core/session.py` → `dsp/playback.py` remains valid for buffer-based
   workflows.

2. **Session grows new methods that use the Scheduler.** Where a user
   today would call `session.generate_tone(freq, beats, amp)` and get a
   numpy buffer back, the same user will soon be able to call something
   like `session.play_pattern(pattern, shape)` and get SignalFlow-backed
   live playback routed through the Scheduler. The two paths coexist.

3. **`core/session.py` is already 2566 LOC and doing too much.** Before
   adding Scheduler integration, Session should be pared down (see the
   repo-prep phase in SKILL.md). Do not attempt to hang the Scheduler off
   a bloated Session.

4. **Tempo handling must match the existing codebase.** MDMA already has
   a `session.bpm` attribute used throughout (`duration_sec = beats * 60.0
   / self.bpm`). The new Clock should reuse `session.bpm` when the user
   runs in integrated mode, not introduce a second tempo source.

The rest of this spec defines the Scheduler proper, unchanged by the
merge context.

---

## Purpose

The `Scheduler` is the live dispatch engine that owns a shared clock and
routes `Pattern` events to the audio graph. It supersedes `Pattern.play()` for
anything involving concurrency, looping, mutation, or automation.

`Pattern.play()` remains valid as a standalone convenience for single-pattern
sequential playback. The Scheduler is purely additive.

Two scheduler classes live side by side and share a common clock:

- **`Scheduler`** — handles standard `Pattern` instances at event rate.
- **`PARScheduler`** — handles `PAR` instances at audio rate, with batched
  dispatch to avoid the event-loop overhead that would choke the base
  scheduler.

Both schedulers consume the same clock and the same input controller, so
anything driving the clock or the controller drives both.

---

## Clock

### Units

The clock is **seconds-based internally**. All dispatch timing is in seconds.

BPM is exposed as a convenience layer on top. The clock carries a `tempo`
attribute (BPM). When a pattern is scheduled with `unit="beats"`, its
durations are interpreted as beats and converted to seconds at schedule time
using the current tempo. When scheduled with `unit="seconds"` (default),
durations pass through unchanged.

### Integration with existing Session BPM

When a `Clock` is constructed by Session (rather than standalone), it should
read its initial tempo from `session.bpm` and propagate tempo changes in
both directions: `session.set_bpm(...)` should update the Clock, and
`clock.set_tempo(...)` should update `session.bpm`. The goal is one tempo
source visible everywhere.

Standalone Clock usage (for tests, for non-Session consumers) does not
require Session and constructs with its own tempo.

### Interface

```python
class Clock:
    tempo: float         # BPM, default 120.0
    running: bool        # True while the clock is actively advancing

    def start(self) -> None: ...
    def stop(self) -> None: ...
    def now(self) -> float:
        """Current absolute time in seconds since start()."""

    def set_tempo(self, bpm: float) -> None:
        """Thread-safe tempo change. Takes effect on the next tick.
        When bound to a Session, also updates session.bpm."""

    def beats_to_seconds(self, beats: float) -> float:
        return beats * (60.0 / self.tempo)
```

Changing tempo mid-playback does **not** retroactively re-time already-scheduled
events; it only affects conversions from beats to seconds that happen after the
change.

### Tick granularity

The scheduler does not expose a fixed tick rate. Both schedulers run their
own loops and consult the clock as needed. PARScheduler's loop runs at a
higher rate than Scheduler's by design.

---

## Scheduler (Event-Rate)

### Responsibilities

1. Accept `Pattern` instances scheduled to start at a given absolute or
   relative time.
2. Dispatch pattern events through `shape` and the pattern's `chain`, same as
   `Pattern.play()`.
3. Support concurrent patterns.
4. Support looping via explicit loop handles.
5. Support live mutation (pattern replacement at next event boundary or on
   next schedule).
6. Accept parameter automation bindings (see Automation section below).

### Core interface

```python
class Scheduler:
    def __init__(self, clock: Clock, graph: AudioGraph): ...

    def add(
        self,
        pattern: Pattern,
        shape: Callable,
        *,
        start: float = 0.0,       # seconds from now, or absolute if start_mode="absolute"
        start_mode: str = "relative",  # "relative" | "absolute"
        unit: str = "seconds",    # "seconds" | "beats"
    ) -> ScheduleHandle:
        """Schedule a pattern for one-shot playback. Returns a handle for
        control and mutation."""

    def loop(
        self,
        pattern: Pattern,
        shape: Callable,
        *,
        start: float = 0.0,
        start_mode: str = "relative",
        unit: str = "seconds",
    ) -> LoopHandle:
        """Schedule a pattern to loop continuously. Returns a loop handle
        with .stop() for clean exit."""

    def start(self) -> None:
        """Start the scheduler loop. Also starts the clock if not running."""

    def stop(self) -> None:
        """Stop the scheduler and cancel all pending events."""
```

### ScheduleHandle

Returned by `.add()`. Represents one scheduled pattern playthrough.

```python
class ScheduleHandle:
    pattern: Pattern        # current pattern (may be replaced via .swap)
    start_time: float       # absolute seconds, resolved at schedule time
    active: bool            # True while events are still pending

    def cancel(self) -> None:
        """Cancel remaining events. Events already dispatched continue to
        their natural end."""

    def swap(self, new_pattern: Pattern) -> None:
        """Replace the pattern. Takes effect at the next event boundary —
        the currently-playing voice (if any) finishes naturally, then
        subsequent events come from new_pattern. If new_pattern is shorter
        than the remaining events, playback ends when new_pattern is
        exhausted."""
```

**Swap semantics (confirming mutation models 1 and 2 from planning):**

- Replacing a pattern entirely for next schedule → `.add()` a new one.
- Swapping at next event boundary → `.swap()` on the handle.
- Swapping mid-event → **not supported in v1**, deliberately out of scope.

### LoopHandle

Returned by `.loop()`. Represents a continuous looping pattern.

```python
class LoopHandle(ScheduleHandle):
    iterations: int         # read-only, increments each time the pattern restarts

    def stop(self) -> None:
        """Stop looping at the end of the current iteration. Currently-playing
        voice finishes naturally."""

    def stop_immediately(self) -> None:
        """Stop looping and cancel any remaining events in the current
        iteration. Currently-playing voice finishes naturally."""
```

**"Safe continuous loop" semantics:** `.stop()` lets the current iteration
complete; the loop exits at the natural boundary. This is the default
graceful exit. `.stop_immediately()` is the hard-cut variant.

### Concurrency

Multiple `.add()` / `.loop()` calls run concurrently. Each handle has its own
event cursor. The scheduler dispatch loop walks all active handles every tick
and fires any events whose time has arrived.

### Shape and chain dispatch

Identical to `Pattern.play()` behavior: for each event, `shape(note)` builds
the voice, `pattern.chain` is applied in order, the result is `.play()`ed on
the graph, and `.stop()`ed when the duration elapses.

**Key difference from `Pattern.play()`:** The scheduler does **not**
`graph.wait(dur)` — it relies on the clock to know when to stop each voice.
This is what enables concurrency.

---

## PARScheduler (Audio-Rate)

### Purpose

`PAR` patterns have much higher event density than regular patterns. Dispatching
one event at a time through the standard scheduler loop would choke on the
overhead. `PARScheduler` uses batched dispatch: it pre-computes the next N
milliseconds of events and hands them to SignalFlow in a single shot.

### PAR class

```python
class PAR(Pattern):
    mod_speed: float  # default 1.0

    def __init__(self, patt: list[tuple[float, float]], mod_speed: float = 1.0):
        super().__init__(patt)
        self.mod_speed = mod_speed
```

`mod_speed` is a density/rate multiplier. Effective duration of each event is
`duration / mod_speed`. This lets you write patterns in readable ratio form
and crank up the density via a single parameter, rather than authoring with
micro-decimal durations.

`mod_speed` lives in **both** places:

- **On the PAR instance** — baked in at construction as a default.
- **On the schedule call** — `par_scheduler.add(par, shape, mod_speed=4.0)`
  overrides the instance value for that schedule.

The schedule-level override is what the handle exposes for live mutation.

### PARScheduleHandle

```python
class PARScheduleHandle(ScheduleHandle):
    mod_speed: float        # current effective mod_speed

    def set_mod_speed(self, mod_speed: float) -> None:
        """Live mutation of mod_speed. Takes effect on the next batch."""
```

### Core interface

```python
class PARScheduler:
    def __init__(self, clock: Clock, graph: AudioGraph, batch_ms: float = 50.0): ...

    def add(
        self,
        pattern: PAR,
        shape: Callable,
        *,
        start: float = 0.0,
        start_mode: str = "relative",
        unit: str = "seconds",
        mod_speed: float | None = None,  # None → use pattern.mod_speed
    ) -> PARScheduleHandle: ...

    def loop(
        self,
        pattern: PAR,
        shape: Callable,
        *,
        start: float = 0.0,
        start_mode: str = "relative",
        unit: str = "seconds",
        mod_speed: float | None = None,
    ) -> PARLoopHandle: ...

    def start(self) -> None: ...
    def stop(self) -> None: ...
```

### Batched dispatch

On each tick of the PAR loop, for each active handle:

1. Compute how many events fall within the next `batch_ms` window, factoring
   in current `mod_speed`.
2. Construct voices for those events, apply their chains, and hand them to
   SignalFlow as a batch.
3. Advance the handle's cursor.

`batch_ms` is tunable. Smaller = more responsive to `mod_speed` changes,
higher overhead. Larger = less responsive, better performance. Default 50ms
is a starting point; tune empirically.

### Implementation note for the code generator

PARScheduler is the most performance-sensitive part of the library.
Straightforward Python dispatch will not keep up at high `mod_speed` values.
Profile early and consider:

- Pre-computing all voices for a batch in a tight loop before any graph
  interaction.
- Reusing voice nodes where possible rather than allocating per-event.
- Keeping the hot path free of attribute lookups on chain entries (resolve
  chain once per handle, not per event).

These are optimization notes, not spec requirements. Get correctness first.

---

## Automation

Automation is the scheduler scheduling parameter *values* rather than note
events. An `AutomationSource` produces a time-varying float; a binding
connects that source to a target parameter.

v1 scope covers three targets:

1. **Chain parameter automation** — automate a parameter inside a playing
   pattern's chain (e.g., the `cutoff` of a `.bf("lpf", cutoff)`).
2. **PAR `mod_speed` automation** — automate the density of a PAR.
3. **Scheduler-level automation** — automate tempo and master volume.

Out of scope for v1: automating transform arguments retroactively (e.g.,
`.fast(live_source)`). Defer.

### AutomationSource

```python
class AutomationSource:
    def value_at(self, t: float) -> float:
        """Return the source's value at absolute time t (seconds)."""

    def start(self, t0: float) -> None:
        """Called when the source is bound and the scheduler is running.
        t0 is the absolute start time."""

    def stop(self) -> None:
        """Called when the binding is removed or the scheduler stops."""
```

Concrete source types (at minimum):

- **`Constant(value)`** — trivial; for testing and for holding values while
  a binding is active.
- **`LFO(shape, rate, depth, offset)`** — sine/saw/square/triangle at a given
  rate (Hz or beats), scaled by depth and offset.
- **`Ramp(start, end, duration)`** — linear interpolation over `duration`
  seconds. Stays at `end` after.
- **`Envelope(points)`** — breakpoint envelope, list of `(time, value)`
  pairs, linear between points.
- **`ControllerSource(controller, key)`** — reads from an InputController
  channel. See InputController spec.

### Binding interface

Bindings live on the scheduler (not on the pattern) because automation is a
scheduler-level concern that needs the clock.

```python
class Scheduler:
    def bind_chain_param(
        self,
        handle: ScheduleHandle,
        chain_index: int,
        param_name: str,
        source: AutomationSource,
    ) -> BindingHandle:
        """Bind an automation source to a parameter of a chain entry on a
        playing pattern. chain_index is the position in pattern.chain."""

    def bind_mod_speed(
        self,
        handle: PARScheduleHandle,
        source: AutomationSource,
    ) -> BindingHandle: ...

    def bind_tempo(self, source: AutomationSource) -> BindingHandle: ...
    def bind_master_volume(self, source: AutomationSource) -> BindingHandle: ...

class BindingHandle:
    def unbind(self) -> None: ...
```

### Automation dispatch

On each scheduler tick, for each active binding, the scheduler reads
`source.value_at(clock.now())` and pushes the value to the target:

- Chain-param bindings update the live SignalFlow node's parameter.
- `mod_speed` bindings update the PAR handle's `mod_speed` (which the
  PARScheduler picks up on its next batch).
- Tempo bindings update `clock.tempo`.
- Master volume bindings update the graph's output level.

**Update rate:** One value per scheduler tick. For chain params this means
control-rate automation, not audio-rate. If audio-rate parameter modulation
is needed, that's a DSP-chain concern (use `.mod()` with a SignalFlow
modulator node), not an automation-binding concern.

---

## Render

Render produces an offline audio file from scheduled patterns. Always
produces audio (wav); always faster than real-time where possible.

### Single-pattern render (A)

```python
def render_pattern(
    pattern: Pattern,
    shape: Callable,
    out_path: str,
    *,
    sample_rate: int = 48000,
    bit_depth: int = 16,
) -> None:
    """Render a single pattern offline to a wav file. Applies the pattern's
    chain. Duration is the sum of event durations."""
```

For PAR patterns, accepts an optional `mod_speed` override, same as scheduler
`.add()`.

### Schedule-section render (B)

```python
def render_schedule(
    scheduler: Scheduler | PARScheduler,
    out_path: str,
    *,
    duration: float,
    sample_rate: int = 48000,
    bit_depth: int = 16,
) -> None:
    """Render `duration` seconds of the scheduler's current schedule offline
    to a wav file. All currently-scheduled patterns (including loops) are
    included. Automation bindings are honored.

    The scheduler must not be running — call .stop() first if needed.
    This is a destructive operation in the sense that it walks the schedule;
    after rendering, the schedule state is consumed."""
```

**Why render is more performant than live scheduling:** render runs offline
at whatever rate the graph can manage, with no real-time constraint. A
pattern that chokes live (e.g., PAR at extreme `mod_speed`) will render
cleanly, because there's no wall clock to miss.

### Interop with existing Session buffer flow

The existing MDMA codebase treats `session.last_buffer` (numpy array) as the
canonical "current audio" that effects, the render commands, and AI analysis
all read from. When the new render functions produce a wav, they should also
**populate `session.last_buffer` when called from Session**, so the rest of
the system sees the rendered audio in the same way it sees a buffer from
`generate_tone`. This is the primary bridge between the SignalFlow path and
the legacy buffer path.

For standalone render calls (not through Session), `session.last_buffer`
updates are obviously not applicable.

### Future extension (out of scope for v1)

A `render_to_buffer` variant that produces an in-memory buffer instead of a
wav file. Relevant for a future GUI frontend that wants to freeze a pattern
and play the buffer cheaply. **Do not architect the render path in a way
that forecloses this** — keep the audio production step separable from the
wav-writing step so a buffer-producing variant can share the core renderer.

---

## Relationship to Pattern

The Scheduler does not replace `Pattern.play()`. `Pattern.play()` remains
the simple path for single-pattern sequential playback.

The Scheduler is the path for:

- Multiple concurrent patterns
- Looping with clean stop semantics
- Live mutation
- Parameter automation
- Input controller integration
- Rendering

Patterns don't know about the Scheduler. Schedulers consume Patterns.

---

## Error Handling Summary

| Condition | Behavior |
|-----------|----------|
| `.add()` or `.loop()` with non-Pattern | `TypeError` |
| `PARScheduler.add()` with non-PAR | `TypeError` |
| `.swap()` with wrong subclass (e.g., PAR into Pattern handle) | `TypeError` |
| `bind_chain_param` with out-of-range `chain_index` | `IndexError` |
| `bind_chain_param` with unknown `param_name` | `ValueError` |
| `render_schedule` while scheduler is running | `RuntimeError` |
| Setting `tempo <= 0` | `ValueError` |
| Setting `mod_speed <= 0` | `ValueError` |

---

## Open Questions / Future Work

1. **Mid-event swap.** Deliberately excluded. Revisit if live-performance
   needs pressure it.
2. **Transform-argument automation** (`.fast(live_source)`). Deliberately
   excluded. Would require Pattern to understand automation sources, which
   entangles it with the scheduler.
3. **`render_to_buffer`.** Future extension for GUI frontend. Keep render
   path architecturally separable.
4. **Quantization at schedule time.** Not in v1. `start` is literal seconds
   or beats; no snapping to bar/beat grids.
5. **MIDI clock sync / OSC transport.** Out of scope; belongs in
   InputController territory if anywhere.
6. **DJ mode integration.** Existing `dsp/dj_mode.py` is a concurrent
   multi-deck audio mixer. Its control logic (deck selection, crossfade,
   deck-specific effects) should eventually route through the Scheduler
   rather than its own ad-hoc loop, but this is a significant port. Not
   in v1.
