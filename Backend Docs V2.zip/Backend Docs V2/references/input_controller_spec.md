# InputController Spec — MDMA Backend V2

## Merge Context

This spec defines the `InputController` for the MDMA backend — a new
component being added to the existing MDMA codebase. Relevant notes for
the merge:

1. **No existing equivalent in the old codebase.** MDMA's current input
   model is REPL-only (stdin → command parser → Session). The
   InputController is new territory, not a replacement.

2. **The existing REPL is not in scope for this spec.** The command
   router in `bmdma.py` (currently being extracted to
   `commands/router.py`) handles typed slash-commands. The
   InputController handles physical/hardware input — keyboard events,
   MIDI, OSC, gamepad. These are complementary, not competing.

3. **Command invocation from InputController handlers.** A natural use
   case is "MIDI pad press triggers a slash command." The handler
   architecture in this spec supports arbitrary Python callbacks, so a
   handler can invoke the command router just like the REPL does. No
   special integration required; it falls out naturally.

4. **Accessibility constraint, flagged in SKILL.md too.** The author uses
   NVDA as a screen reader on Windows. The `KeyboardController` must not
   globally grab keyboard focus or interfere with NVDA's event handling.
   See that section below.

The rest of this spec defines the InputController proper, unchanged by
the merge context.

---

## Purpose

The `InputController` is an agnostic input layer that translates any physical
input source (computer keyboard, gamepad, MIDI device, OSC client, future
hardware) into a unified internal protocol consumable by the Scheduler and by
`AutomationSource` bindings.

The goal: **any controller can drive any scheduler or automation target**,
without the scheduler or the rest of the backend knowing what kind of
controller is on the other end.

---

## Internal Protocol

All input sources produce **InputEvent** and **InputValue** records.

### InputEvent

Discrete events — a key press, a note-on, an OSC message arrival.

```python
@dataclass
class InputEvent:
    timestamp: float      # seconds, clock time at dispatch
    kind: str             # event type, see below
    key: str              # stable identifier within this controller
    value: float | None   # optional scalar payload (e.g., velocity)
    meta: dict | None     # optional extra data (channel, raw bytes, etc.)
```

**Standard `kind` values:**

- `"press"` — momentary press (keyboard key down, MIDI note-on, pad hit).
- `"release"` — momentary release (key up, note-off).
- `"trigger"` — one-shot event with no natural release (OSC bang, MIDI
  program change).

Controllers may emit additional `kind` values for device-specific events,
but consumers should only rely on the three above for portable behavior.

### InputValue

Continuous values — a CC sweep, a joystick axis, an OSC float stream.

Exposed via a channel interface rather than per-sample events, so that
`AutomationSource` can sample it at whatever rate it needs:

```python
class InputChannel:
    key: str              # stable identifier within the controller
    def read(self) -> float:
        """Current value of this channel, typically in [0.0, 1.0] or
        [-1.0, 1.0] depending on the channel's semantics."""

    def range(self) -> tuple[float, float]:
        """Declared range of this channel, e.g. (0.0, 1.0)."""
```

Rationale: events are pushed (the controller emits them when they happen);
continuous values are pulled (the automation source reads them when it
needs them). This matches how MIDI CC, OSC, and gamepad axes behave in
practice and avoids spamming the event queue with redundant samples.

---

## Controller Interface

Every controller implements:

```python
class Controller:
    name: str                       # human-readable, e.g. "Launchpad Mini"

    def start(self) -> None:
        """Open the device / socket / listener."""

    def stop(self) -> None:
        """Close cleanly."""

    def poll(self) -> list[InputEvent]:
        """Return any events that have arrived since the last poll.
        Non-blocking. Called by the InputController on each tick."""

    def channels(self) -> dict[str, InputChannel]:
        """Return a dict of continuous channels exposed by this controller,
        keyed by stable identifier."""
```

Concrete controllers implement this interface. The InputController itself
owns a set of controllers and aggregates their events and channels.

---

## InputController

The top-level aggregator. Owned by whoever is coordinating the system
(typically the user's main script or Session, not the scheduler itself).

```python
class InputController:
    def __init__(self, clock: Clock): ...

    def add_controller(self, controller: Controller, alias: str) -> None:
        """Register a controller under a namespace alias. Events and channels
        from this controller become accessible as 'alias.key'."""

    def remove_controller(self, alias: str) -> None: ...

    def start(self) -> None:
        """Start all registered controllers."""

    def stop(self) -> None: ...

    def poll(self) -> list[InputEvent]:
        """Aggregate poll across all controllers. Events have their `key`
        rewritten as 'alias.original_key'."""

    def channel(self, path: str) -> InputChannel:
        """Look up a channel by 'alias.key' path. Used by ControllerSource
        in the automation system."""

    def on(self, kind: str, key: str, handler: Callable[[InputEvent], None]) -> HandlerHandle:
        """Register a handler for events matching kind and key.
        key is the full 'alias.original_key' path or a glob pattern."""
```

### Namespace aliases

Multiple controllers of the same type (e.g., two MIDI keyboards) need
distinct namespaces. The `alias` passed to `add_controller` becomes the
prefix on all keys from that controller:

```python
ic.add_controller(MidiController(port=0), alias="mk1")
ic.add_controller(MidiController(port=1), alias="mk2")

# Events from port 0 come through as "mk1.note_60", port 1 as "mk2.note_60"
# Channels similarly: "mk1.cc_7", "mk2.cc_7"
```

---

## Integration with Scheduler

The InputController is **not** owned by the Scheduler. The user wires them
together explicitly:

```python
clock = Clock()
graph = AudioGraph()
sched = Scheduler(clock, graph)
ic = InputController(clock)

ic.add_controller(KeyboardController(), alias="kb")
ic.add_controller(MidiController(port=0), alias="mk1")

ic.start()
sched.start()

# Drive an automation binding from a MIDI CC
source = ControllerSource(ic, "mk1.cc_7")  # reads ic.channel("mk1.cc_7")
sched.bind_chain_param(melody_handle, chain_index=0, param_name="cutoff", source=source)

# Drive a scheduler action from a keyboard event
def handle_space(event):
    sched.loop(drums, saw)
ic.on("press", "kb.space", handle_space)
```

### Scheduler hooks

The scheduler exposes two lightweight integration points rather than owning
the controller:

1. `AutomationSource.ControllerSource` — the automation source that reads
   from an `InputChannel`. Lives in the scheduler's automation layer but
   takes an `InputController` reference at construction.
2. Handler-driven control — the user's script wires `ic.on(...)` handlers
   to scheduler methods directly. The InputController doesn't need to know
   about the scheduler.

This separation keeps both sides simple and testable.

### Integration with Session and the command router

A natural use case in the merged codebase: a MIDI pad press fires a slash
command. The handler simply calls into the command router. Sketch:

```python
from mdma_rebuild.commands import router  # extracted in repo-prep

def pad_1_handler(event):
    router.dispatch(session, "beat", ["trap", "4"])

ic.on("press", "mk1.note_36", pad_1_handler)
```

This is not a special InputController feature — it's just a handler that
happens to call the router. Noted here so the integration path is obvious.

---

## Concrete Controllers (v1)

### KeyboardController

Reads computer keyboard events. Primarily for development and testing.

- `kind="press"` / `kind="release"` for key down/up.
- `key` is the key name, lowercase, e.g. `"a"`, `"space"`, `"enter"`.
- No continuous channels.
- **NVDA compatibility (required):** Do not install a global keyboard
  hook. Read keys only when the Python process has focus, via a stdin/
  curses-style loop or a focus-scoped event listener. A global hook would
  intercept keystrokes before NVDA sees them, breaking the screen reader.
  This is non-negotiable for accessibility. If a cross-platform library
  is used (e.g., `pynput`), use its focused-mode API, not its global-hook
  API.
- `start()` should require an explicit user action (e.g., the user runs
  a specific command) so keyboard capture is never on by default.

### MidiController

Reads from a MIDI input port.

- `kind="press"` for note-on with velocity > 0, `kind="release"` for
  note-off (or note-on with velocity 0).
- `key` is `note_{n}` for notes (e.g., `"note_60"`).
- Continuous channels: `cc_{n}` for each CC, value in `[0.0, 1.0]`
  (normalized from MIDI's 0-127).
- `meta` includes channel number, raw velocity.
- Uses `mido` or equivalent.

### OSCController

Reads from an OSC UDP socket.

- `kind="trigger"` for incoming OSC messages (OSC doesn't have a natural
  press/release model; single bangs are the norm).
- `key` is the OSC address, with slashes converted to dots:
  `/synth/cutoff` → `"synth.cutoff"`.
- Continuous channels created dynamically on first message to a given
  address carrying a float payload.

### GamepadController (v1.1, flag as future)

Reads from a gamepad via `pygame` or `inputs`.

- `kind="press"` / `kind="release"` for buttons.
- `key` is the button name, e.g. `"a"`, `"dpad_up"`, `"lt"`.
- Continuous channels: `axis_{name}` in `[-1.0, 1.0]`, e.g. `axis_lx`.

v1 should implement Keyboard, Midi, and OSC. Gamepad is deferred but the
Controller interface must not foreclose it.

---

## Handler Model

`ic.on(kind, key, handler)` registers a callback. Handlers are invoked
from the `InputController.poll()` loop, which is called from the scheduler's
tick (or from a dedicated InputController thread — see threading note
below).

```python
class HandlerHandle:
    def remove(self) -> None: ...
```

### Glob matching

`key` accepts glob patterns for convenience:

```python
ic.on("press", "mk1.note_*", lambda e: print(e.key))  # any note on mk1
ic.on("trigger", "*.cc_7", lambda e: ...)             # cc_7 from any controller
```

Matching is string-glob (`fnmatch`-style), against the full namespaced key.

### Handler exceptions

Handler exceptions must not kill the InputController loop. Wrap each
handler invocation in a try/except that logs but doesn't propagate. This
is critical for live performance.

---

## Threading

The InputController runs its own polling loop on a background thread. This
is necessary because:

- Some controllers (OSC, MIDI) have blocking reads.
- Scheduler ticks should not stall waiting on input.

Thread-safety requirements:

- `poll()` and handler invocations happen on the InputController thread.
- Channel reads (`channel.read()`) must be atomic — typically a single
  attribute read of a float, which is atomic in CPython.
- Handlers may be invoked on the InputController thread. If a handler
  mutates scheduler state, the scheduler's own mutation methods must be
  thread-safe (this is a scheduler requirement, not an InputController
  requirement — flagged here for cross-reference).
- Handlers that call into the command router also invoke Session
  methods, which must likewise be thread-safe. Session in the current
  codebase is not fully thread-safe; during the merge, any Session
  methods called from handlers need audit and (likely) a coarse-grained
  lock.

---

## Error Handling Summary

| Condition | Behavior |
|-----------|----------|
| `add_controller` with duplicate alias | `ValueError` |
| `channel(path)` with unknown path | `KeyError` |
| `on(kind, key, ...)` with no matching controller | Handler registered anyway; may match future controllers |
| Controller fails to start (e.g., MIDI port missing) | Controller's `start()` raises; `InputController.start()` propagates |
| Handler raises | Logged, not propagated |

---

## Open Questions / Future Work

1. **Output controllers.** This spec is input-only. LED feedback to MIDI
   controllers, OSC-out to visualizers, etc. would require a parallel
   output layer. Out of scope.
2. **MIDI clock sync.** If a MIDI device sends clock, should the Clock
   follow it? Not in v1 — the Clock is the master. Revisit.
3. **Recording and playback of input streams.** Useful for reproducing a
   live take. Deferred.
4. **Gamepad controller.** Interface-ready; implementation deferred.
5. **Learn mode.** "Move a control, have the system auto-bind it to the
   most recently touched automation target." Classic live-coding ergonomic
   feature. Deferred, but wouldn't require protocol changes.
