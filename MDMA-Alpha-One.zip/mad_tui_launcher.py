#!/usr/bin/env python
"""Simple launcher for the MDMA Textual TUI.

Run: python mad_tui_launcher.py
"""
from mad_tui import main

if __name__ == '__main__':
    main()
