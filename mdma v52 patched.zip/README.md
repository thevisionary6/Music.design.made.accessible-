# MDMA v14.2

**Music Design Made Accessible**

Command-line audio production environment designed for screen reader accessibility
and zero-vision workflows.

## Version Info

- **Version:** 14.2
- **Build ID:** mdma_v14.2_20260127
- **Status:** Stable Release

## Installation

```bash
# Create virtual environment (recommended)
python -m venv .venv
.venv\Scripts\activate  # Windows
# or: source .venv/bin/activate  # Linux/Mac

# Install dependencies (with audio playback)
pip install numpy scipy soundfile sounddevice

# Verify installation
python -c "from mdma_rebuild import __version__; print(f'MDMA v{__version__}')"

# Verify audio backend
python -c "from mdma_rebuild.dsp.playback import get_backend; print(f'Backend: {get_backend()}')"
```

## Quick Start

### Generate and Play Audio

```python
from mdma_rebuild.core.session import Session

# Create session
s = Session()
s.bpm = 120

# Generate tone
s.generate_tone(440.0, 1.0, 0.8)  # A4, 1 beat, 80% amplitude

# Play directly (in-house playback, no external media player)
result = s.play()
print(result)  # "PLAYING: 0.50s via sounddevice"

# Stop playback
s.stop_playback()
```

### Playback Commands

```bash
# Play current buffer
/play              # Play at default volume
/play 50           # Play at 50% volume

# Control playback
/stop              # Stop playback
/vol 75            # Set volume to 75%
/status            # Show playback status

# Test audio
/test              # Play 440Hz test tone
/test 880 1.0      # Play 880Hz for 1 second

# Check backend
/backend           # Show audio backend info
```

### Pattern Commands

```bash
# Apply pitch pattern
/pat 0 7 12 5           # Major chord arpeggio

# Use chord presets
/arp maj                 # Major triad
/arp min7 4              # Minor 7th, 4 repeats

# Buffer manipulation
/reverse                 # Reverse buffer
/pitch 7                 # Up a fifth
```

### Effects with 1-100 Scaling

All parameters use consistent 0-100 scale:

```python
from mdma_rebuild.dsp.effects import fx_buffer

# Apply effects
result = fx_buffer(audio, ['saturate_tube'], amount=75)
```

## What's New in v14.2

### In-House Audio Playback (Chunk 3)

- **No external media players** - Audio plays directly via sounddevice/simpleaudio
- **Non-blocking playback** - Background thread playback
- **Volume control** - `/vol` command
- **Status tracking** - `/status` command
- **Cross-platform** - Windows, macOS, Linux

### Previous Features

- **v14.1:** Unified 1-100 parameter scaling, audio-rate pattern modulation

## Package Structure

```
mdma_rebuild/
├── __init__.py           # Version info
├── core/
│   └── session.py        # Session management + playback
├── dsp/
│   ├── scaling.py        # Parameter scaling
│   ├── monolith.py       # Synth engine
│   ├── effects.py        # 51 audio effects
│   ├── pattern.py        # Pattern modulation
│   ├── playback.py       # In-house audio playback (NEW)
│   └── envelopes.py      # ADSR envelopes
└── commands/
    ├── playback_cmds.py  # Playback commands (NEW)
    ├── pattern_cmds.py   # Pattern commands
    ├── fx_cmds.py        # Effect commands
    └── ...
```

## Audio Backends

Priority order:
1. **sounddevice** (recommended) - `pip install sounddevice`
2. **simpleaudio** - `pip install simpleaudio`
3. **pyaudio** - `pip install pyaudio`
4. **fallback** - File-based if no backend

## Documentation Files

- `README.md` - This file
- `VERSION.md` - Version details
- `DEPENDENCIES.txt` - Requirements
- `RELEASE_NOTES.md` - Complete release notes

## Accessibility Features

- **In-house playback** - No external media player popups
- **Consistent scales** - All parameters use 0-100
- **Preset names** - Human-readable alternatives
- **Clear feedback** - All operations report in text
- **Screen reader compatible** - No visual dependencies

## License

MDMA - Music Design Made Accessible
Built for vision-optional audio production
